<template>
    <Main />
</template>

<script setup>
import Main from '@/components/Main.vue';
</script>
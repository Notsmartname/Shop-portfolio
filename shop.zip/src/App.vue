<template>
    <NavBar />
    <router-view />
</template>


<script setup>
import NavBar from '@/components/NavBar.vue';
import Main from '@/components/Main.vue';



</script>


<style scoped></style>

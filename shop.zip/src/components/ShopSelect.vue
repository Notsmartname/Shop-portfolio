<template>
    <select @change="changeSelect()">
        <option disabled value="">Сортировка:</option>
        <option v-for="option in options" :key="option.value">{{ option.name }}</option>
    </select>
</template>

<script setup>
const emit = defineEmits(['changeSelect'])
const props = defineProps({
    options: {
        type: Array,
        default: () => [],
        required: true,
    },
    selectedOption: String,
});



</script>

<style lang="scss" scoped>
select {
    padding: 5px;
    border-radius: 5px;
}
</style>